''' Python 3. feladatsor'''

''' -------------------------------------------------------------    '''

''' 1.Feladat: Karakterek száma a fájlban.'''
''' Írj egy függvényt karakterek_szama néven amely paraméterként egy fájlnevet kap és visszatér a fájlban levő karakterek számával. ('\n karakterekkel együtt')'''


#assert karakterek_szama("lorem.txt") == 18047

''' -------------------------------------------------------------  '''

''' 2. Feladat: Sorok száma a fájlban. '''
''' A sorok_szama(fname) függvény visszatér a  fájlban levő sorok számával.   ''


#assert sorok_szama("lorem.txt") == 82

''' -------------------------------------------------------------'''

''' 3. Feladat: lorem szavak száma a fájlban. '''
''' A lorem_szavak_szama(fname) függvény visszatér a  fájlban levő "lorem" szavak számával.'''


#assert lorem_szavak_szama("lorem.txt") == 27 

''' -------------------------------------------------------------    '''

''' 4. Feladat: String fájlba írása'''
''' Készíts függvényt string_fajlba néven, amely az első paraméterként kapott sztringet fájlba írja.'''
''' A fájl nevét második paraméterként kapja meg a függvény.'''


#string_fajlba("csacska macska", "szoveg.txt"); assert open("szoveg.txt").read().strip() == "csacska macska"

''' -------------------------------------------------------------'''

''' 5. Feladat: Négyzet osztály definiálása. [Objektumorientált programozás]'''
''' Hozz létre egy osztályt Negyzet néven.'''
''' A Negyzet osztály lehetővé teszi a negyzet oldalhosszúságának tárolását.'''
''' A Negyzet osztály rendelkezik egy kerulet() nevü metódussal, amely az osztály segítségével létrehozott objektum metódusaként visszaadja az adott objektum kerületét.'''
''' A Negyzet osztály rendelkezik egy terulet() nevü metódussal, amely az osztály segítségével létrehozott objektum metódusaként visszaadja az adott objektum területét.'''


#assert Negyzet(3).kerulet() == 12
#assert Negyzet(3).terulet() == 9
''' -------------------------------------------------------------'''

''' 6. Feladat: Számtani sorozat fájlba írása'''
''' Készíts függvényt szaz_szam_fajlba néven, amely 1-tól 100-ig egyesével kiírja a számokat egy fájlba.'''
''' Minden szám kerüljön új sorba.'''
''' A fájl nevét paraméterként kapja meg a függvény.'''


#szaz_szam_fajlba("szazas.txt"); assert len(open("szazas.txt").read())
#szaz_szam_fajlba("szazas.txt"); assert sum([int(i) for i in open("szazas.txt")]) == 5050

''' --------------------------------------------------------------------------------------------'''

''' 7. Feladat: Számok átlaga egy szövegfájlban.'''
''' Írj egy függvényt szamok_atlaga_a_fajlban néven, amely visszatér egy szövegfájlban levő számok átlagával.'''
''' A függvény bemenő paramétere a fájl neve.'''


#assert szamok_atlaga_a_fajlban("szamok1.txt") == 1.0

''' --------------------------------------------------------------------------------------------'''

''' 8. Feladat: Pozitívok egy szövegfájlból.'''
''' Írj egy függvényt pozitiv_a_fajlbol néven, amely visszatér a szövegfájlban levő pozitiv számokkal mint listával.'''
''' A függvény bemenő paramétere a fájl neve.'''


#assert pozitivok_a_fajlbol("szamok1.txt") == [4, 3, 2, 1, 4, 3, 2, 1, 4, 4]

''' --------------------------------------------------------------------------------------------'''

''' 9. Feladat: Hárommal osztható számok a szövegfájlban.'''
''' Írj egy függvényt harommal_oszthato_szamok_a_fajlban néven, amely visszatér a szövegfájlban levő hárommal osztható számok listájával.'''
''' A függvény bemenő paramétere a fájl neve.'''


#assert harommal_oszthato_szamok_a_fajlban("szamok1.txt") == [3, 3, 0, -6, 0]

'''======================================================================================'''

