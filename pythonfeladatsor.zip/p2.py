''' Minden feladatra 2 pont adható'''
''' ------------------------------------------------------------------------------------------ '''

''' 1. Feladat: Legnagyobb szám a listában. [Programozási tétel: Maximum kiválasztás] '''
''' Készíts függvényt legnagyobb néven,  amely visszatér egy számokat tartalmazó lista legnagyobb számával. '''
''' Figyelem! A feladat megoldása során nem használhatod a max függvényt! '''


#assert legnagyobb( [7, 4, 9, -4, -8, 3] ) == 9

''' ----------------------------------------------------------------------------------------- '''

''' 2. Feladat: Listaban levő számok összege. [Programozási tétel: Összegzés] '''
''' Készíts függvényt osszeg néven,  amely visszatér egy számokat tartalmazó lista számainak összegével. '''
''' Figyelem! A feladat megoldása során nem használhatod a sum() függvényt! '''


#assert osszeg( [1, 2, 3, 4, 5, 6] ) == 21
    
''' ---------------------------------------------------------------------------------------- '''

''' 3. Feladat: Pozitív számok száma a listában. [Programozási tétel: Megszámolás] '''
''' Készíts függvényt pozitivok_szama néven,  amely visszatér egy számokat tartalmazó lista pozitív számainak számával. '''


#assert pozitivok_szama( [-7, -4, 9, -4, -8, 3, 1, 0]) == 3
   
''' ---------------------------------------------------------------------------------------- '''

''' 4. Feladat: Benne van a szám a listában? [Programozási tétel: Eldöntés] '''
''' Készíts függvényt benne_van_a_listaban néven,  amelynek első paramétere egy számokat tartalmazó lista, a második paramétere egy szám. '''
''' A visszatérési érték True, ha  a szám benne van a listában. '''
''' A visszatérési érték False, ha  a szám nics benne a listában. '''

    
#assert benne_van_a_listaban([-7, -4, 9, -4, -8, 3, 1, 0], 2) == False
#assert benne_van_a_listaban([-7, -4, 9, -4, -8, 3, 1, 0], 9) == True

''' ------------------------------------------------------------------------------------------- '''

''' 5. Feladat: Hányadik a listában? [Programozási tétel: Kiválasztás] '''
'''          A listában a szám garantáltan megtalálható, nem kell vizsgálni a meglétét. '''
''' Készíts függvényt hanyadik_a_listaban néven, amelynek első paramétere egy számokat tartalmazó lista, a második paramétere egy szám. '''
''' A visszatérési érték a paraméterként megadott szám első előfordulási helye a listában.'''


#assert hanyadik_a_listában([-7, -4, 9, -4, -8, 3, 1, 0], -7) == 0
#assert hanyadik_a_listában([-7, -4, 9, -4, -8, 3, 1, 0],  9) == 2

''' ------------------------------------------------------------------------------------------- '''

''' 6. Feladat: Első karakter '''
''' Írj egy függvényt elso_karakter néven amely visszatér az adott string első karakterével! '''


#assert elso_karakter("Hello") == "H"

''' ------------------------------------------------------------------------------------------- '''

''' 7. Feladat: Negatív számok számok kiválogatása egy listából. [Programozási tétel: Kiválogatás] '''
''' Készíts függvényt negatívok_kivalogatasa néven,  amely visszatér egy listával amely a paraméterként átadott számokat tartalmazó lista negatív számait tartalmazza. '''


#assert negativok_kivalogatasa( [7, 4, 9, -4, -8, 3, 1, 12, 0] ) == [-4, -8]


'''================================================================================'''