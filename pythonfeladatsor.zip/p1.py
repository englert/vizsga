''' Minden feladatra 2 pont adható'''

''' ---------------------------------------------------------------------------'''

''' 1. Feladat: Melyik a kisebb? '''
''' Írj egy függvényt "kisebb" néven, amely két számot kap és visszatér a legkisebbel.'''
''' Figyelem! a min() függvényt nem hasznáhatod '''


#assert kisebb(12, -8) == -8
#assert kisebb(-8, 12) == -8

''' ----------------------------------------------------------------------------'''

''' 2. Feladat: Kettővel osztható:'''
''' Írj egy "kettovel_oszthato" nevü függvényt, amely egy számot kap bemenetként és True-val tér vissza, ha a szám kettővel osztható és False-al ha nem.'''


#assert kettovel_oszthato(12) == True
#assert kettovel_oszthato(13) == False

''' ----------------------------------------------------------------------------'''

''' 3. Feladat: Téglatest térfogat: '''
''' Írj egy "teglatest_terfogat" nevü függvényt , amely bemenetként megkapja a téglatest oldalainak hosszúságát és a téglatest térfogatával tér vissza.'''

#assert teglatest_terfogat(2, 3, 4) == 24

''' ---------------------------------------------------------------------------'''

''' 4. Feladat: Számtani közép'''
'''Írj "szamtani_kozep" néven függvényt, amely két számot kap bemenetként és visszatér a számtani középpel.'''

#assert szamtani_kozep(3, 5) == 4.0
